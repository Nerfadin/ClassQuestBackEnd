export interface CreateAccountToken {
    id: string,
    institutionId: string,
    email: string,
    createdAt: Date,
}