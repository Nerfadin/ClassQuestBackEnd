export interface ConfigDTO{
    gameVersion: string
    goldmultiplayer: number
    expomultiplaier: number
}