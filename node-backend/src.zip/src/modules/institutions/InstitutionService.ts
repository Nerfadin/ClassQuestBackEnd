import {
  AuthorizationError,
  UnexpectedError,
  EntityNotFoundError,
} from "../../utils/errorUtils";
import { UserService } from "../users/UserService";
import { InstitutionFirestoreAdaptor } from "./InstitutionFirestoreAdaptor";
import { EmailService } from "../email/EmailService";
import { InviteTeachersDto } from "./InviteTeachersDto";
import dayjs from "dayjs";
import { firestore } from "firebase-admin";
import { TaskService } from "../tasks/TaskService";
import { Singleton, Inject } from "../../utils/tsyringe";
@Singleton()
export class InstitutionService {
  constructor(
    @Inject(() => InstitutionFirestoreAdaptor)
    private institutionDao: InstitutionFirestoreAdaptor,
    @Inject(() => UserService) private userDao: UserService,
    @Inject(() => EmailService) private emailService: EmailService,
    @Inject(() => TaskService) private taskService: TaskService
  ) {}
  async createInstitution(createDto: any, teacherId: string) {
    // TODO: CreateInstitutionDto
    const institution = await this.institutionDao.createInstitution(
      createDto,
      teacherId
    );
    const now = dayjs();
    const inOneMonth = now.add(1, "month");
    const security: any = {
      //TODO: InstitutionSecurity
      id: institution.id,
      plan: "paid",
      freeTrialStart: firestore.Timestamp.fromDate(now.toDate()),
      freeTrialEnd: firestore.Timestamp.fromDate(inOneMonth.toDate()),
    };
    await this.institutionDao.setInstitutionSecurity(institution.id, security);
    await this.taskService.scheduleInstitutionFreeTrialRemovalTask(security);
    await this.institutionDao.addTeacherToInstitution(
      teacherId,
      institution.id,
      "diretor"
    );
  }

  async inviteTeachers(data: InviteTeachersDto): Promise<void> {
    const teacherPlan = await this.institutionDao
      .getTeacherInstitutionPlan(data.directorId, data.institutionId)
      .catch((err) => {
        throw err instanceof EntityNotFoundError
          ? new AuthorizationError({
              message: "Teacher is not in institution",
              details: err,
            })
          : err;
      });

    if (!["diretor", "coordenador"].includes(teacherPlan.role)) {
      throw new AuthorizationError({
        message: "Insufficient permissions.",
      });
    }

    const tokenResults = await Promise.all(
      data.teachers
        .map((teacher) =>
          this.userDao.createUserRegisterToken(
            teacher.email,
            data.institutionId
          )
        )
        .map((token) => token.catch((err) => err as Error))
    );

    const sendEmailResults = await Promise.all(
      tokenResults.map((res, i) =>
        typeof res === "string"
          ? this.emailService
              .sendInviteTeacherEmail({
                email: data.teachers[i].email,
                token: res,
                name: data.teachers[i].name,
                institutionId: data.institutionId,
              })
              .catch((err) => err as Error)
          : Promise.resolve(res)
      )
    );

    const failures = sendEmailResults.filter(
      (e) => e instanceof Error
    ) as Error[];

    if (failures.length) {
      throw new UnexpectedError({ details: failures });
    } else return;
  }
}
