import { IsNotEmpty } from "class-validator";

export class InviteTeachersDto {
  @IsNotEmpty()
  directorId: string;
  @IsNotEmpty()
  institutionId: string;
  @IsNotEmpty()
  teachers: {
    name: string
    email: string;
  }[];
}