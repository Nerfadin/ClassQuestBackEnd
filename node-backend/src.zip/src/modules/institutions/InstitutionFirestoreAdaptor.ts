import { adminDb } from "../../app";
import { oneDocumentP } from "../../utils/firestoreUtils";
import { firestore } from "firebase-admin";
import { TEACHERS } from "../groups/GroupFirebaseAdaptor";
import { UserFirestoreAdaptor } from "../users/UserFirestoreAdaptor";
import { Singleton, Inject } from "../../utils/tsyringe";
export const INSTITUTIONS_HAS_TEACHERS = "institutions_has_teachers";
export const INSTITUTIONS = "institutions";
export const INSTITUTION_SECURITY = "institution_security";
type TeacherInstitutionPlan = {
  groups: number;
  id: string;
  quests: number;
  questsInGroups: number;
  teacher: firestore.DocumentReference;
  institution: firestore.DocumentReference;
  role: InstitutionRoles;
  joinedAt: firestore.Timestamp;
};

export type InstitutionRoles = "diretor" | "coordenador" | "teacher";

@Singleton()
export class InstitutionFirestoreAdaptor {
  constructor(
    @Inject(() => UserFirestoreAdaptor) private userDao: UserFirestoreAdaptor
  ) {}

  getTeacherInstitutionPlan(teacherId: string, institutionId: string) {
    return oneDocumentP<TeacherInstitutionPlan>( // TODO: TeacherInstitutionPlan
      adminDb
        .collection(INSTITUTIONS_HAS_TEACHERS)
        .doc(`${teacherId}_${institutionId}`)
        .get()
        );
  }

  async createInstitution(createDto: any, teacherId: string) {
    // TODO: CreateInstitutionDto
    return await adminDb.collection(INSTITUTIONS).add(createDto);
  }

  async addTeacherToInstitution(
    teacherId: string,
    institutionId: string,
    role: any = "teacher" // TODO: InstitutionRoles
  ) {
    const plan: Omit<TeacherInstitutionPlan, "id"> = {
      quests: 0,
      groups: 0,
      questsInGroups: 0,
      teacher: adminDb.collection(TEACHERS).doc(teacherId),
      institution: adminDb.collection(INSTITUTIONS).doc(institutionId),
      role,
      joinedAt: firestore.Timestamp.fromDate(new Date()),
    };
    //add teacher to InstitutionHasTeacher
    this.setTeacherPlan(teacherId, institutionId, plan);
    //add institution to teachers lnstitution array
    this.userDao.updateTeacher(teacherId, {
      institutionIds: firestore.FieldValue.arrayUnion(institutionId),
    });
  }
  async setInstitutionSecurity(
    institutionId: string,
    update: any // TODO: UpdateFirestoreDocument<InstitutionSecurity>
  ) {
    return adminDb
      .collection(INSTITUTION_SECURITY)
      .doc(institutionId)
      .set(update);
  }
  async setTeacherPlan(
    teacherId: string,
    institutionId: string,
    update: any // TODO: UpdateFirestoreDocument<TeacherInstitutionPlan>
  ) {
    return adminDb
      .collection(INSTITUTIONS_HAS_TEACHERS)
      .doc(`${teacherId}_${institutionId}`)
      .set(update, { merge: true });
  }
}
