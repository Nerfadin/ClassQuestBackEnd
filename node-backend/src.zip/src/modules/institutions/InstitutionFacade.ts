import { InstitutionService } from "./InstitutionService";
import { InviteTeachersDto } from "./InviteTeachersDto";
import { Singleton, Inject } from "../../utils/tsyringe";
import { validateDto } from "../../utils/validateDto";
@Singleton()
export class InstitutionFacade {
  constructor(
    @Inject(() => InstitutionService)
    private institutionService: InstitutionService
  ) {}
  inviteTeachers(data: InviteTeachersDto) {
    return validateDto(InviteTeachersDto)(data).then(
      this.institutionService.inviteTeachers
    );
  }
}
