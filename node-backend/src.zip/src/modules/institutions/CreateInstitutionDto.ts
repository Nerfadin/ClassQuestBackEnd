export interface CreateInstitutionDto {

    id: string,
    name: string,
    
}