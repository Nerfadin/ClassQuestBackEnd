import { Inject, Singleton } from "../../utils/tsyringe";
import { MessageFireBaseAdapter } from './MessageFirebaseAdapter';



@Singleton()
export class MessageFacade {
    constructor(
        @Inject(() => MessageFireBaseAdapter) private messagesDao: MessageFireBaseAdapter,
        
      ) {}


      async getMessagesFromGroup (groupPin: string){
       const messagesPin = await this.messagesDao.getGroupMessagesId(groupPin);
       return await this.messagesDao.GetMessages(messagesPin);

      }
}