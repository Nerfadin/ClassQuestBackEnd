import { Group } from "@interfaces/groups";
import { EntityNotFoundError } from "../../utils/errorUtils";
import { oneDocumentP } from "../../utils/firestoreUtils";
import { singleton } from "tsyringe";
import { adminDb } from "../../app";
import { MessageDto } from "./MessageDto";
export const GROUPS = "groups";
export const MESSAGES = "messages"
//pin teste *q*KNW
@singleton()
export class MessageFireBaseAdapter {
    // TODO: Alterar essa chamada para usar o message Service
    getGroupMessagesId(id: string) {
        return oneDocumentP<Group>(adminDb.collection(GROUPS).doc(id).get()).catch(
          (err) => {
            throw err instanceof EntityNotFoundError
              ? new EntityNotFoundError({
                  type: "group_not_found",
                  message: "Grupo não encontrado",
                  details: err,
                })
              : err;
          }

        ).then ((group) => group.messages);

      }

      async GetMessages(ids: string[]) {
        const docRefs = ids.map((id) => adminDb.collection(MESSAGES).doc(id));
        const firestoreMessages = await Promise.all(
          docRefs.map((d) =>
            oneDocumentP<MessageDto>(d.get()).catch((_err) => undefined)
          )
        );
        const messagesAvailable = firestoreMessages.filter(
          (message) => !!message
        ) as MessageDto[];
        return messagesAvailable;
      }
}
