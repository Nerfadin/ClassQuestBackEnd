export interface MessageDto {

    title: string,
    message: string,
    visualizedBy: string[]
    createdAt: Date
}

export interface messageInfo {
    title: string
    createdAt: Date
}