export type messageInGroup = {
    title: string,
    message: string,
    group: string[]
}