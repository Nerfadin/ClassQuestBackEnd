import { LoginDto } from "./models/LoginDto";
import { AuthenticationHttpAdaptor } from "./AuthenticationHttpAdaptor";
import { RegisterDtoStepTwo, RegisterDtoStepOne } from "./models/RegisterDto";
import { Singleton, Inject } from "../../utils/tsyringe";
import { UserService } from "../users/UserService";
import { Player } from "../../../../packages/interfaces/player";
const playerBaseStats: Partial<Player> = {
  email: "",
  firstName: "",
  lastName: "",
  currentHealth: 100,
  maxHealth: 100,
  gender: "",
  playerName: "",
  groupIds: [],
  questIds: [],
  inventory: [],
  level: 1,
  gold: 130,
};
@Singleton()
export class AuthenticationService {
  constructor(
    @Inject(() => AuthenticationHttpAdaptor)
    private authenticationDao: AuthenticationHttpAdaptor,
    @Inject(() => UserService) private userService: UserService
  ) {}

  login(loginDto: LoginDto) {
    return this.authenticationDao.login(loginDto);
  }

  async registerAnonymously(name: string) {
    const register = await this.authenticationDao.register();
    await this.userService.savePlayerStats(register.localId, {
      completedQuests: {},
      completedQuestsCount: 0,
    });
    await this.userService.savePlayer(register.localId, {
      ...playerBaseStats,
      playerName: name,
      characterCreated: true,
    });
    return register;
  }

  async registerStepOne(registerDto: RegisterDtoStepOne) {
    const register = await this.authenticationDao.register(registerDto);
    await this.userService.savePlayerStats(register.localId, {
      completedQuests: {},
      completedQuestsCount: 0,
    });
    await this.userService.savePlayer(register.localId, {
      ...playerBaseStats,
      email: registerDto.email,
      firstName: registerDto.firstName,
      lastName: registerDto.lastName,
      characterCreated: false,
    });
    return register;
  }

  registerStepTwo(registerDto: RegisterDtoStepTwo, userId: string) {
    return this.userService
      .savePlayer(userId, {
        playerName: registerDto.playerName,
        gender: registerDto.gender,
        characterCreated: true,
      })
      .then(() => this.userService.getPlayer(userId));
  }

  refreshToken = this.authenticationDao.refreshToken;
}

export function isNonAnonymousRegister(obj: any): obj is RegisterDtoStepOne {
  return obj.email && obj.password;
}
