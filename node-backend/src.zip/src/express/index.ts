import express from "express";
import cors from "cors";
import bodyParser from "body-parser";
import {
  expressErrorHandler,
  returnFailureOrSuccessExpress,
  verifyAuthenticated,
} from "./express-helpers";
import { build } from "../utils/tsyringe";
import { InstitutionFacade } from "../modules/institutions/InstitutionFacade";
import { ShopService } from "../modules/shop/ShopService";
import { DailyService } from "../modules/daily/DailyService";
import { QuestService } from "../modules/quests/QuestService";
import { UserService } from "../modules/users/UserService";
import { GroupService } from "../modules/groups/GroupService";
import { TimerService } from "../modules/timers/TimerService";
import { AuthenticationService } from "../modules/authentication/AuthenticationService";
import { getRoutes } from "../utils/printRoutes";
import { ConfigService } from "../modules/globalConfig/ConfigService";
import { MessageFacade } from '../modules/Messages/MessageFacade';


export const app = express();
app.use(cors({ origin: true }));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));

app.get(
  "/messageFromGroup", returnFailureOrSuccessExpress((req) => {
    const messageFacade = build(MessageFacade);
    return messageFacade.getMessagesFromGroup("*OUYcC"); 
  })
)
app.get(
  "/message/:groupId/group", returnFailureOrSuccessExpress((req) => {
    const messageFacade = build(MessageFacade);
    return messageFacade.getMessagesFromGroup(req.params.groupId); 
  })
)
app.get(
  "/config",
  returnFailureOrSuccessExpress((req) => {
    const configService = build(ConfigService);
    return configService.getConfig();
  })
)
app.post(
  "/institutions/:institutionId/teachers",
  verifyAuthenticated(),
  returnFailureOrSuccessExpress((req) => {
    const user = req.user;
    const institutionFacade = build(InstitutionFacade);
    return institutionFacade.inviteTeachers({
      teachers: req.body.teachers,
      directorId: user.uid,
      institutionId: req.params.institutionId,
    });
  })
);
app.get(
  "/shop",
  verifyAuthenticated(),
  returnFailureOrSuccessExpress((req) => {
    const shopService = build(ShopService);
    return shopService.getShopItems();
  })
);
app.get(
  "/daily/progress",
  verifyAuthenticated(),
  returnFailureOrSuccessExpress((req, user) => {
    const dailyService = build(DailyService);
    return dailyService.getCurrentProgress(user.uid);
  })
);
app.get(
  "/daily",
  verifyAuthenticated(),
  returnFailureOrSuccessExpress((req, user) => {
    const dailyService = build(DailyService);
    return dailyService.claimDailyReward(user.uid);
  })
);
app.get(
  "/quests/:questId",
  verifyAuthenticated(),
  returnFailureOrSuccessExpress((req) => {
    const questsService = build(QuestService);
    return questsService.getQuest(req.params.questId);
  })
);
app.get(
  "/players/:playerId",
  verifyAuthenticated(),
  returnFailureOrSuccessExpress((req) => {
    const userService = build(UserService);
    return userService.getPlayer(req.params.playerId);
  })
);
app.patch(
  "/players/:playerId",
  verifyAuthenticated(),
  returnFailureOrSuccessExpress((req) => {
    const userService = build(UserService);
    return userService.savePlayer(req.params.playerId, req.body);
  })
);
app.get(
  "/groups/:groupId",
  verifyAuthenticated(),
  returnFailureOrSuccessExpress((req) => {
    const groupsService = build(GroupService);
    const user = req.user;
    return groupsService.getGroupsAndQuests(req.params.groupId, user.uid);
  })
);
app.get(
  "/teachers/:teacherId",
  verifyAuthenticated(),
  returnFailureOrSuccessExpress((req) => {
    const userService = build(UserService);
    return userService.getTeacher(req.params.teacherId);
  })
);
app.post(
  "/quests/:questId/answers",
  verifyAuthenticated(),
  returnFailureOrSuccessExpress((req, user) => {
    const questsService = build(QuestService);
    const body = req.body;
    // body.groupId = req.params.groupId;
    body.questId = req.params.questId;
    return questsService.submitAnswer(req.body, user.uid);
  })
);
app.get(
  "/quests/:questId/report",
  verifyAuthenticated(),
  returnFailureOrSuccessExpress((req) => {
    const questsService = build(QuestService);
    return questsService.getReport(req.params.questId);
  })
);
app.get(
  "/players/:playerId/groups",
  verifyAuthenticated(),
  returnFailureOrSuccessExpress((req) => {
    const groupsService = build(GroupService);
    return groupsService.getGroupsByPlayer(req.params.playerId);
  })
);

app.get(
  "/groups/:groupId/quests",
  verifyAuthenticated(),
  returnFailureOrSuccessExpress((req, user) => {
    const groupsService = build(GroupService);
    return groupsService.getGroupsQuests(req.params.groupId, user.uid);
  })
);
app.get(
  "/reports",
  verifyAuthenticated(),
  returnFailureOrSuccessExpress((req, user) => {
    const questsService = build(QuestService);
    return questsService.getReports(req.user.uid);
  })
);
app.get(
  "/timers/:name",
  verifyAuthenticated(),
  returnFailureOrSuccessExpress((req, user) => {
    const timerService = build(TimerService);
    return timerService.getTimer(user.uid, req.params.name);
  })
);
app.put(
  "/timers/:name",
  verifyAuthenticated(),
  returnFailureOrSuccessExpress((req, user) => {
    const timerService = build(TimerService);
    return timerService.saveTimer(user.uid, {
      name: req.params.name,
      expiresIn: req.body,
    });
  })
);
app.delete(
  "/timers/:name",
  verifyAuthenticated(),
  returnFailureOrSuccessExpress((req, user) => {
    const timerService = build(TimerService);
    return timerService.deleteTimer(user.uid, req.params.name);
  })
);
app.post(
  "/login",
  returnFailureOrSuccessExpress((req) => {
    const authService = build(AuthenticationService);
    return authService.login(req.body);
  }, false)
);
app.post(
  "/register",
  returnFailureOrSuccessExpress((req) => {
    const authService = build(AuthenticationService);
    return authService.registerStepOne(req.body);
  }, false)
);
app.post(
  "/register/2",
  verifyAuthenticated(),
  returnFailureOrSuccessExpress((req, user) => {
    const authService = build(AuthenticationService);
    return authService.registerStepTwo(req.body, user.uid);
  })
);
app.post(
  "/register/anonymously",
  returnFailureOrSuccessExpress((req) => {
    const authService = build(AuthenticationService);
    return authService.registerAnonymously(req.body.name);
  })
);
app.post(
  "/refreshToken",
  returnFailureOrSuccessExpress((req) => {
    const authService = build(AuthenticationService);
    return authService.refreshToken(req.body);
  }, false)
);
app.get("/", (req, res) => {
  res.send(`
    <h3> Hello World! </h3>
    <h4> Routes: </h4>
    ${getRoutes(app)
      .filter((t) => !t.includes(","))
      .map((r) => "<p>" + r + "</p>")}
  `);
});
app.use((req, res, next) => {
  res.status(404).send({
    statusCode: 404,
    name: "Error",
    message: "Rota não encontrada",
  });
});
app.use(expressErrorHandler);
export default app;
